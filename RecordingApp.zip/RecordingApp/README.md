# RecordingApp
 latest dependency
 ###  Final UI

![App UI](/ui.jpg)
